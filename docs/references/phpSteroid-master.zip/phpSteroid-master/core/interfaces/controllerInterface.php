<?php
    interface controllerInterface{
        function index();
    }
?>