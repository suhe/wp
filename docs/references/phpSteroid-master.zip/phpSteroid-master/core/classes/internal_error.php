<?php
    class internal_error{
        
        static function show($type){
            echo "{$type} Error";
        }
        
    }
?>