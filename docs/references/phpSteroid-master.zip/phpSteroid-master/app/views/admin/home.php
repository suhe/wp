<?php load::view("admin/template/head"); ?>
<?php load::view("admin/template/foot"); ?>