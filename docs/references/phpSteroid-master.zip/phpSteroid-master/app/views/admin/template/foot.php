        </div>
        <div class='foot'>
            &copy; <?=date("Y")?> <a href="//the4.net">The 4 Syndicate LLC.</a>
        </div>
    </body>
</html>